# go-detailedreport-to-csv

Export Veracode detailedreport XML to CSV

## Usage

```
$ ./go-detailedreport-to-csv path/to/detailedreport_DIR/detailedreport_NAME.xml 
Successfully Opened path/to/detailedreport_DIR/detailedreport_NAME.xml
Wrote output.csv
All done
```
